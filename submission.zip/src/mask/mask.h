class Mask
{
public: 
    Mask(int cells_in_x, int cells_in_y);

    enum cell_type;
};